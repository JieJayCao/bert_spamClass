


fi=open("/Users/jiecao/Documents/program/GitHub/bert-for-task-master/evaloutput.txt",'a')
current_step=1
loss=1
acc=1
recall=1
prec=1
f_beta=1
print("train: step: {}, loss: {}, acc: {}, recall: {}, precision: {}, f_beta: {}".format(
                        current_step, loss, acc, recall, prec, f_beta))

x=("train: step: {}, loss: {}, acc: {}, recall: {}, precision: {}, f_beta: {}".format(
                        current_step, loss, acc, recall, prec, f_beta))


fi.write(x+'\n')