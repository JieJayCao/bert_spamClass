f1=open("test.txt",'r')
f2=open("test1.txt",'a')

for line in f1.readlines():
    #line=line.replace('\t','\<SEP>')
    line=line.split('\t')
    if line[1]=='1\n':
        line[1]="spam"
    else:
        line[1]="ham"
    f2.write(line[0]+'\<SEP>'+line[1]+'\n')
    