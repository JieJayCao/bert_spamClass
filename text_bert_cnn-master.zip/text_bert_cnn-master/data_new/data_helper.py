f1=open('data_new/dev.txt','r')
f2=open('data_new/train.txt','r')
f3=open('data_new/test.txt','r')

f4=open('data_new/dev1.txt','a')
f5=open('data_new/test1.txt','a')
f6=open('data_new/train1.txt','a')


for line in f3.readlines():
    line=line.split('\t')

    f5.write(line[1].replace('\n','')+'\t'+line[0]+'\n')
